export function reverseAString(str: string): string {

}

// console.log(reverseAString('hello'));
// console.log(reverseAString('Howdy'));