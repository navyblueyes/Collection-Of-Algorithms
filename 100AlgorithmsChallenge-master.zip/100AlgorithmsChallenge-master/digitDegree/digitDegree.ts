export function digitDegree(n: number): number {

}

// console.log(digitDegree(5));
// console.log(digitDegree(10));
// console.log(digitDegree(91));