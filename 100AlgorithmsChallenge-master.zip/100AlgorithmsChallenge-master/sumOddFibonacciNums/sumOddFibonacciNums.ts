export function sumOddFibonacciNums(num: number): number {

}

// console.log(sumOddFibonacciNums(1000));
// console.log(sumOddFibonacciNums(4000000));
// console.log(sumOddFibonacciNums(10));