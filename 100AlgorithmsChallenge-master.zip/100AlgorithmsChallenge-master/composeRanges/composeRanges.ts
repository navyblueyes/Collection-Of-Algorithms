export function composeRanges(nums: number[]): string[] {

}

// console.log(composeRanges([-1, 0, 1, 2, 6, 7, 9]));