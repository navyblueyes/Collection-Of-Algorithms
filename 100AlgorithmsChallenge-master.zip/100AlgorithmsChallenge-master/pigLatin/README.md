### Check Out My [YouTube Channel](https://www.YouTube.com/CodingTutorials360)

### Check Out More Algorithms like this at <a href="https://www.FreeCodeCamp.com"> FreeCodeCamp</a>
---
Translate the provided string to pig latin.

Pig Latin takes the first consonant (or consonant cluster) of an English word, moves it to the end of the word and suffixes an "ay".

If a word begins with a vowel you just add "way" to the end.

Input strings are guaranteed to be English words in all lowercase.

**Example**
-   pigLatin("glove") should return "oveglay".
-   pigLatin("eight") should return "eightway".

**Hints**
-   split()
-   test()
-   join()
-   push()