export function pigLatin(str: string): string {

}

// console.log(pigLatin("glove"));
// console.log(pigLatin("eight"));
