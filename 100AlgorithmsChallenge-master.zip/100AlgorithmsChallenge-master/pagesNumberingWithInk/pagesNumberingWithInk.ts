export function pagesNumberingWithInk(current: number, numberOfDigits: number): number {

}

// console.log(pagesNumberingWithInk('G'));