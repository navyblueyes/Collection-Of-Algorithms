export function newNumeralSystem(number: string): string[] {

}

// console.log(newNumeralSystem('G'));