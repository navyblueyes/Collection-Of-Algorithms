export function isCaseInsensitivePalindrome(inputString: string): boolean {

}

// console.log(isCaseInsensitivePalindrome('AaBaa'));
// console.log(isCaseInsensitivePalindrome('abac'));