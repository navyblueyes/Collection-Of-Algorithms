export function encloseInBrackets(inputString: string): string {

}

// console.log(encloseInBrackets('abacaba'));