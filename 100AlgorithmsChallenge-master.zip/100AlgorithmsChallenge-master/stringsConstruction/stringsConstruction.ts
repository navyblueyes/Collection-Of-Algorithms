export function stringsConstruction(a: string, b: string): number {

}

// console.log(stringsConstruction('abc', 'abccba'));