export function isLucky(n: number): boolean {

}

// console.log(isLucky(1230));
// console.log(isLucky(239017));