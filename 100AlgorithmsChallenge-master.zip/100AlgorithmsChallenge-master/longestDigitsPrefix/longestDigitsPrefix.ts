export function longestDigitsPrefix(inputString: string): string {

}

// console.log(longestDigitsPrefix('123aa1'));