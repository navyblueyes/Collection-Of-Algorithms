export function firstNotRepeatingCharacter(s: string): string {

}

// console.log(firstNotRepeatingCharacter('abacabad'));
// console.log(firstNotRepeatingCharacter('abacabaabacaba'));
