export function convertString(s: string, t: string): boolean {

}

// console.log(convertString('ceoydefthf5iyg5h5yts', 'codefights'));
// console.log(convertString('addbyca', 'abcd'));
