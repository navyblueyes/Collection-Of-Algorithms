export function arrayMaxConsecutiveSum(inputArray: number[], k: number): number {

}

// console.log(arrayMaxConsecutiveSum([2, 3, 5, 1, 6], 2));