export function largestNumber(n: number): number {

}

// console.log(largestNumber(2));