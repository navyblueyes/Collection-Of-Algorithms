export function confirmEnding(str: string, target: string) {

}

// console.log(confirmEnding("Abstraction", "action"));
// console.log(confirmEnding("Open sesame", "pen"));