export function mostFrequentDigitSum(n: number): number {

}

// console.log(mostFrequentDigitSum(88));
// console.log(mostFrequentDigitSum(8));