export function differentSymbolsNaive(s: string): number {

}

// console.log(differentSymbolsNaive('cabca'));
