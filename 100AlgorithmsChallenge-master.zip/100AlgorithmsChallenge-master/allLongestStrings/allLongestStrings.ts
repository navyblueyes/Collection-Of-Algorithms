export function allLongestStrings(inputArray: string[]): string[] {

}

console.log(allLongestStrings(["aba", "aa", "ad", "vcd", "aba"]));