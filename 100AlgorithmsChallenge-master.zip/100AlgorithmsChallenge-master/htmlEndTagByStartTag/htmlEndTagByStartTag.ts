export function htmlEndTagByStartTag(startTag: string): string {

}

// console.log(htmlEndTagByStartTag("<button type='button' disabled>"));
// console.log(htmlEndTagByStartTag('<i>'));