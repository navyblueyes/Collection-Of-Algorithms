### Check Out My [YouTube Channel](https://www.YouTube.com/CodingTutorials360)

### Check Out More Algorithms like this at <a href="https://www.FreeCodeCamp.com"> FreeCodeCamp</a>
---
Find the missing letter in the passed letter range and return it.

If all letters are present in the range, return undefined.

**Example**
-   missingLetters("abce") should return "d".
-   missingLetters("abcdefghjklmno") should return "i".
-   missingLetters("abcdefghijklmnopqrstuvwxyz") should return undefined.

**Hints**
-   split()