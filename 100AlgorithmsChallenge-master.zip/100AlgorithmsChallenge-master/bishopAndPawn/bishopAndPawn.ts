export function bishopAndPawn(bishop: string, pawn: string): boolean {

}

// console.log(bishopAndPawn('a1', 'c3'));