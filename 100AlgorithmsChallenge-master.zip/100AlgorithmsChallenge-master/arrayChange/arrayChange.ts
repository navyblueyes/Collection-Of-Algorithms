export function arrayChange(inputArray: number[]): number {

}

// console.log(arrayChange([1, 1, 1]));