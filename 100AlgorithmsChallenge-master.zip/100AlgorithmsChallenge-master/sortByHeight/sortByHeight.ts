export function sortByHeight(a: number[]): number[] {

}

// console.log(sortByHeight([-1, 150, 190, 170, -1, -1, 160, 180]));