export function matrixElementsSum(matrix: any[][]): number {

}

// console.log(matrixElementsSum(
//     [[0, 1, 1, 2],
//     [0, 5, 0, 0],
//     [2, 0, 3, 3]]
// ));
