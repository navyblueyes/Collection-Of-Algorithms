export function arrayPreviousLess(items: number[]): number[] {

}

// console.log(arrayPreviousLess([3, 5, 2, 4, 5]));