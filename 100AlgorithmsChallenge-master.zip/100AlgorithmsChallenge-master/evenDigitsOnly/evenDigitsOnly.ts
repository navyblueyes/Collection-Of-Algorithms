export function evenDigitsOnly(n: number): boolean {

}

// console.log(evenDigitsOnly(248622));
// console.log(evenDigitsOnly(642386));