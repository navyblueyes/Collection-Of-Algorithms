export function minesweeper(matrix: boolean[][]): number[][] {

}

// console.log(minesweeper([[true, false, false],
// [false, true, false],
// [false, false, false]]));