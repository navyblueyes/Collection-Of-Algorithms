export function fancyRide(l: number, fares: number[]): string {

}

// console.log(fancyRide(30, [0.3, 0.5, 0.7, 1, 1.3]));