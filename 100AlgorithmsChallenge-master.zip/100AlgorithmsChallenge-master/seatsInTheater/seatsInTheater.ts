export function seatsInTheater(nCols: number, nRows: number, col: number, row: number): number {

}

// console.log(seatsInTheater(16, 11, 5, 3));