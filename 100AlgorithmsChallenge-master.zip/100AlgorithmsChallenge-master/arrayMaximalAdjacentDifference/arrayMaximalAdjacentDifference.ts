export function arrayMaximalAdjacentDifference(inputArray: number[]): number {

}

// console.log(arrayMaximalAdjacentDifference([2, 4, 1, 0]));