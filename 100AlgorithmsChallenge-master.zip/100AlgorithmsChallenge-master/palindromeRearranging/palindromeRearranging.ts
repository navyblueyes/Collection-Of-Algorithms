export function palindromeRearranging(inputString: string): boolean {

}

// console.log(palindromeRearranging('aabb'));