export function factorializeANumber(num: number): number {

}

// console.log(factorializeANumber(5));
// console.log(factorializeANumber(10));