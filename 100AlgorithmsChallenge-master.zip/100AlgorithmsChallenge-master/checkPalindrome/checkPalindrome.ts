export function checkPalindrome(inputString: string): boolean {

}

// console.log(checkPalindrome('aabaa'));
// console.log(checkPalindrome('abac'));
// console.log(checkPalindrome('a'));
