export function ratingThreshold(threshold: number, ratings: number[][]): number[] {

}

// console.log(ratingThreshold(3.5, 
//     [[3, 4],
//     [3, 3, 3, 4],
//     [4]]));