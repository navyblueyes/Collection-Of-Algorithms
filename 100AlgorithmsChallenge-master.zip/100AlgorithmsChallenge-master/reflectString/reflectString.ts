export function reflectString(inputString: string): string {

}

// console.log(reflectString("name"));
