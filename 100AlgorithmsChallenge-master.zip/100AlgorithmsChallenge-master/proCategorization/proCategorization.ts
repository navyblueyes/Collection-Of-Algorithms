export function proCategorization(pros: string[], preferences: string[][]): string[][][] {

}

// console.log(proCategorization(["Jack", "Leon", "Maria"], [["Computer repair", "Handyman", "House cleaning"],
// ["Computer lessons", "Computer repair", "Data recovery service"],
// ["Computer lessons", "House cleaning"]]));